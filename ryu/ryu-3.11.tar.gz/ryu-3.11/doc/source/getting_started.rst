***************
Getting Started
***************

.. include:: ../../README.rst
