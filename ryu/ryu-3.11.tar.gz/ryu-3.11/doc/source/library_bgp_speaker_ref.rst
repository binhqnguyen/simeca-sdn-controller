*********************************
BGP speaker library API Reference
*********************************

BGPSpeaker class
================

.. autoclass:: ryu.services.protocols.bgp.bgpspeaker.BGPSpeaker
   :members:

.. autoclass:: ryu.services.protocols.bgp.bgpspeaker.EventPrefix
   :members:
